paragraph=input().split(" ")
print(len(paragraph))